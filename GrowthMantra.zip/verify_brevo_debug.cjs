var SibApiV3Sdk = require('sib-api-v3-sdk');
var defaultClient = SibApiV3Sdk.ApiClient.instance;

// Configure API key authorization: api-key
var apiKey = defaultClient.authentications['api-key'];
apiKey.apiKey = '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';

var apiInstance = new SibApiV3Sdk.AccountApi();

console.log("Verifying API Key...");

apiInstance.getAccount().then(function (data) {
    console.log('API Key is valid.');
    console.log('Email: ' + data.email);
}, function (error) {
    console.error('API Key check failed.');
    console.error('Error status:', error.status);
    if (error.response && error.response.text) {
        console.error('Response body:', error.response.text);
    }
});
