// src/App.tsx
// src/App.tsx
import Index from "./pages/Index";
import "./App.css";

export default function App(): JSX.Element {
  return (
    <div className="app-root">
      <Index />
    </div>
  );
}
