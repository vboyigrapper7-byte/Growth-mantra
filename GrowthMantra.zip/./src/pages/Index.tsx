import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Scene from "../components/Scene";
import { ArrowRight, CheckCircle2, Globe, Bot, Cpu, ChevronDown, Star, Plus, Minus, Rocket, ShoppingBag, Leaf, Loader2, X } from "lucide-react";

type Service = {
  title: string;
  icon: JSX.Element;
  description: string;
  bullets: string[];
};

const services: Service[] = [
  {
    title: "Immersive Digital Experiences",
    icon: <Globe className="w-10 h-10 text-cyan-400" />,
    description: "Next-generation web development featuring 3D visuals, motion graphics, and high-performance architecture.",
    bullets: ["Full-Stack Web Development (A-Z)", "3D Effects & WebGL", "Advanced Motion Animations", "Interactive User Journeys"]
  },
  {
    title: "Enterprise AI Intelligence",
    icon: <Bot className="w-10 h-10 text-purple-400" />,
    description: "Custom generative AI solutions trained on your proprietary data to revolutionize business operations.",
    bullets: ["Custom LLM Training & Fine-Tuning", "Intelligent Business Chatbots", "Generative AI Development", "Automated Workflow Systems"]
  },
  {
    title: "Dominant Growth Ecosystem",
    icon: <Rocket className="w-10 h-10 text-pink-400" />,
    description: "A holistic marketing powerhouse designed to scale your brand aggressively across all channels.",
    bullets: ["Performance Marketing (Ads)", "SEO & Organic Growth", "Brand Identity & Strategy", "Social Media Dominance"]
  }
];

const testimonials = [
  {
    name: "Aditya Mehta",
    role: "Founder, TechSpire Solutions",
    logo: <Cpu className="w-8 h-8 text-cyan-400" />,
    content: "Grow Mantra completely transformed our digital presence. Their AI automation tools saved us countless hours and the lead generation campaign delivered results from day one."
  },
  {
    name: "Priya Sharma",
    role: "Marketing Director, Elevate Fashion",
    logo: <ShoppingBag className="w-8 h-8 text-purple-400" />,
    content: "The team's understanding of the Indian market is exceptional. Our social media engagement skyrocketed, and the new website funnel is converting at 4.5%. Highly recommended!"
  },
  {
    name: "Rahul Verma",
    role: "CEO, GreenLeaf Organics",
    logo: <Leaf className="w-8 h-8 text-green-400" />,
    content: "Professional, data-driven, and creative. They didn't just build a website; they built a growth engine for our brand. The SEO results have been phenomenal."
  }
];

const faqs = [
  {
    question: "What makes Grow Mantra different?",
    answer: "We combine creative marketing with advanced AI technology. Unlike traditional agencies, we build intelligent systems that automate growth, ensuring you get scalable and consistent results."
  },
  {
    question: "Do you work with startups?",
    answer: "Absolutely! We love helping ambitious startups scale. We have tailored packages designed specifically for early-stage growth and can scale our services as your business expands."
  },
  {
    question: "How long does it take to see results?",
    answer: "It depends on the service. Performance marketing can yield results in days, while SEO and brand building are long-term plays (3-6 months). We provide a clear timeline and roadmap for every project."
  },
  {
    question: "What is your pricing model?",
    answer: "We offer both project-based and retainer models. After our initial consultation, we'll recommend the best structure for your specific goals and budget, ensuring maximum ROI."
  }
];

const StatItem: React.FC<{ value: string; label: string; delay: number }> = ({ value, label, delay }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.5, delay }}
    className="text-center p-6 border-t border-white/10"
  >
    <div className="text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500 mb-2">{value}</div>
    <div className="text-sm text-slate-300 font-medium uppercase tracking-wider">{label}</div>
  </motion.div>
);

const ServiceCard: React.FC<{ service: Service; index: number }> = ({ service, index }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
      layout
      onClick={() => setIsOpen(!isOpen)}
      className={`group glass-card p-8 hover:bg-white/5 transition-all duration-500 cursor-pointer overflow-hidden relative ${isOpen ? 'ring-1 ring-cyan-500/50 bg-white/10' : ''}`}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

      <motion.div layout className="flex items-start justify-between relative z-10">
        <div className="w-16 h-16 rounded-2xl bg-slate-950/50 border border-white/10 flex items-center justify-center mb-6 group-hover:scale-110 group-hover:border-cyan-500/30 transition-all duration-300 shadow-lg shrink-0">
          {service.icon}
        </div>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          className="text-slate-500 group-hover:text-cyan-400 transition-colors"
        >
          <ChevronDown className="w-6 h-6" />
        </motion.div>
      </motion.div>

      <motion.h4 layout className="text-2xl font-bold mb-3 text-slate-100 group-hover:text-cyan-300 transition-colors">{service.title}</motion.h4>

      <motion.div
        initial={false}
        animate={{ height: isOpen ? "auto" : 0, opacity: isOpen ? 1 : 0 }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
        className="overflow-hidden relative z-10"
      >
        <p className="text-slate-300 mb-6 text-base leading-relaxed pt-2">{service.description}</p>
        <ul className="space-y-3 pb-2">
          {service.bullets.map((b) => (
            <li key={b} className="flex items-start gap-3 text-sm text-slate-400">
              <CheckCircle2 className="w-4 h-4 text-cyan-500 mt-0.5 shrink-0" />
              <span>{b}</span>
            </li>
          ))}</ul>
      </motion.div>
    </motion.article>
  );
};

const FAQItem: React.FC<{ question: string; answer: string }> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-white/10 last:border-0">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full py-6 flex items-center justify-between text-left focus:outline-none group"
      >
        <span className={`text-lg font-medium transition-colors ${isOpen ? 'text-cyan-400' : 'text-slate-200 group-hover:text-cyan-300'}`}>
          {question}
        </span>
        <span className={`ml-6 shrink-0 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}>
          {isOpen ? <Minus className="w-5 h-5 text-cyan-500" /> : <Plus className="w-5 h-5 text-slate-500 group-hover:text-cyan-400" />}
        </span>
      </button>
      <motion.div
        initial={false}
        animate={{ height: isOpen ? "auto" : 0, opacity: isOpen ? 1 : 0 }}
        transition={{ duration: 0.3 }}
        className="overflow-hidden"
      >
        <p className="pb-6 text-slate-400 leading-relaxed">
          {answer}
        </p>
      </motion.div>
    </div>
  );
};

export default function Index(): JSX.Element {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    if (showSuccess) {
      const timer = setTimeout(() => {
        setShowSuccess(false);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [showSuccess]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    setIsSubmitting(true);

    try {
      // Generate unique event ID for deduplication
      const event_id = crypto.randomUUID ? crypto.randomUUID() : Date.now().toString();

      // Send to local backend
      const submitData = {
        name: data.name,
        email: data.email,
        message: data.message,
        event_id: event_id // Send event_id to backend for CAPI
      };

      const response = await fetch("/api/submit-lead", {
        method: "POST",
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(submitData)
      });

      if (response.ok) {
        // Track Browser Event: Removed Facebook Pixel


        setShowSuccess(true);
        form.reset();
      } else {
        const errorData = await response.json();
        alert(`Error: ${errorData.error || "Something went wrong"}`);
      }
    } catch (error) {
      console.error("Form submission error:", error);
      alert(`Error: ${(error as Error).message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <main className="min-h-screen relative overflow-hidden text-slate-100 selection:bg-cyan-500/30">
      <Scene />



      {/* HERO */}
      <section className="min-h-screen flex flex-col justify-center w-full px-0 pt-20 pb-12 text-center relative z-10 overflow-hidden">
        {/* Video Background - Moved inside Hero */}
        <div className="absolute inset-0 w-full h-full -z-10">
          <video
            autoPlay
            loop
            muted
            playsInline
            className="w-full h-full object-cover"
          >
            <source src="/assets/videos/In_this_video_202512052333.mp4" type="video/mp4" />
            Your browser does not support the video tag.
          </video>
          <div className="absolute inset-0 bg-black/40" /> {/* Slightly darker for white text contrast */}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative z-10 px-4"
        >
          {/* Top Left Logo Placeholder "AI VISION" style - user requested "Grow Mantra" but styled like "AI VISION" */}
          <div className="absolute top-8 left-8 md:top-10 md:left-12 text-white font-bold tracking-[0.2em] text-sm md:text-lg uppercase hidden md:block z-50 drop-shadow-md">
            Grow Mantra
          </div>
          {/* Hamburger Menu Icon - Always Visible as requested */}
          <div className="absolute top-8 right-8 md:top-10 md:right-12 z-50 text-white cursor-pointer" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            <div className="space-y-1.5 p-2 hover:bg-white/10 rounded-lg transition-colors">
              <div className={`w-8 h-0.5 bg-white transition-transform duration-300 ${isMenuOpen ? 'rotate-45 translate-y-2' : ''}`}></div>
              <div className={`w-8 h-0.5 bg-white transition-opacity duration-300 ${isMenuOpen ? 'opacity-0' : ''}`}></div>
              <div className={`w-8 h-0.5 bg-white transition-transform duration-300 ${isMenuOpen ? '-rotate-45 -translate-y-2' : ''}`}></div>
            </div>
          </div>

          {/* Mobile/Overlay Menu */}
          <AnimatePresence>
            {isMenuOpen && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="absolute top-24 right-8 z-40 bg-slate-900/90 backdrop-blur-md border border-white/10 rounded-2xl p-6 flex flex-col gap-4 min-w-[200px] shadow-2xl"
              >
                <a
                  href="#services"
                  onClick={() => setIsMenuOpen(false)}
                  className="text-slate-200 hover:text-cyan-400 font-medium transition-colors text-lg"
                >
                  Services
                </a>
                <a
                  href="#contact"
                  onClick={() => setIsMenuOpen(false)}
                  className="text-slate-200 hover:text-cyan-400 font-medium transition-colors text-lg"
                >
                  Contact
                </a>
                <button
                  onClick={() => {
                    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                    setIsMenuOpen(false);
                  }}
                  className="px-5 py-2 bg-gradient-to-r from-cyan-500 to-purple-500 text-white font-bold rounded-xl hover:opacity-90 transition-opacity"
                >
                  Get Started
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Main Hero Content */}
          <div className="max-w-5xl mx-auto pt-20">
            <h1 className="font-sans font-bold text-white text-5xl md:text-7xl lg:text-8xl leading-[0.9] tracking-tighter mb-6 drop-shadow-2xl">
              Architecting Digital <span className="text-indigo-400 font-extrabold">Futures</span>
            </h1>

            <p className="mt-8 max-w-3xl mx-auto text-slate-200 text-lg md:text-xl leading-relaxed font-medium">
              Beyond traditional websites. We build immersive, high-performance digital ecosystems that define your brand's future.
            </p>

            <div className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-6">
              <a
                className="group relative px-10 py-4 bg-white/10 border border-white/30 text-white font-semibold rounded-full overflow-hidden transition-all hover:bg-white hover:text-black hover:scale-105 backdrop-blur-md"
                href="#contact"
              >
                <span className="relative flex items-center gap-2 tracking-wide">
                  Begin Your Digital Evolution
                </span>
              </a>
            </div>
          </div>
        </motion.div>

        {/* stats row */}
        <div className="mt-24 flex flex-wrap items-center justify-center gap-8 md:gap-12">
          <StatItem value="500+" label="Projects Shipped" delay={0.2} />
          <StatItem value="98%" label="Client Satisfaction" delay={0.4} />
          <StatItem value="10X" label="ROI Generated" delay={0.6} />
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="w-full px-0 py-16 md:py-24 relative z-10">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h3 className="text-4xl md:text-5xl font-extrabold mb-6">
            Our <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">Ecosystem</span>
          </h3>
          <p className="text-slate-400 max-w-2xl mx-auto text-lg">
            End-to-end digital solutions designed to elevate your business and drive measurable results.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s, index) => (
            <ServiceCard key={s.title} service={s} index={index} />
          ))}
        </div>
      </section>

      {/* CONTACT + CTA */}
      <section id="contact" className="w-full px-0 py-16 md:py-24 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          <motion.aside
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8 lg:pt-10"
          >
            <div className="glass-card p-8 border-l-4 border-cyan-500 rounded-r-3xl">
              <h4 className="text-3xl font-bold mb-8 text-white">Get in Touch</h4>
              <div className="space-y-8">
                <div className="flex items-start gap-5 group cursor-pointer">
                  <div className="w-12 h-12 rounded-xl bg-cyan-500/10 flex items-center justify-center shrink-0 group-hover:bg-cyan-500 group-hover:text-slate-900 transition-colors duration-300">
                    <span className="text-2xl">✉️</span>
                  </div>
                  <div>
                    <strong className="block text-slate-200 mb-1 text-lg">Email Us</strong>
                    <div className="text-slate-400 group-hover:text-cyan-400 transition-colors">GrowthMantraSolutions@gmail.com</div>
                  </div>
                </div>
                <div className="flex items-start gap-5 group cursor-pointer">
                  <div className="w-12 h-12 rounded-xl bg-cyan-500/10 flex items-center justify-center shrink-0 group-hover:bg-cyan-500 group-hover:text-slate-900 transition-colors duration-300">
                    <span className="text-2xl">📞</span>
                  </div>
                  <div>
                    <strong className="block text-slate-200 mb-1 text-lg">Call Us</strong>
                    <div className="text-slate-400 group-hover:text-cyan-400 transition-colors">+91 8949692537</div>
                  </div>
                </div>
                <div className="flex items-start gap-5 group cursor-pointer">
                  <div className="w-12 h-12 rounded-xl bg-cyan-500/10 flex items-center justify-center shrink-0 group-hover:bg-cyan-500 group-hover:text-slate-900 transition-colors duration-300">
                    <span className="text-2xl">💬</span>
                  </div>
                  <div>
                    <strong className="block text-slate-200 mb-1 text-lg">Chat with us</strong>
                    <a
                      href="https://wa.me/916377369391"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-cyan-400 font-medium underline decoration-cyan-500/30 underline-offset-4 group-hover:text-cyan-300"
                    >
                      WhatsApp Chat
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-3xl p-8 bg-gradient-to-br from-cyan-600 to-blue-700 text-white shadow-2xl relative overflow-hidden group">
              <div className="absolute top-0 right-0 -mt-4 -mr-4 w-32 h-32 bg-white/20 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-700"></div>
              <h4 className="text-2xl font-bold relative z-10">Ready to Scale?</h4>
              <p className="mt-3 text-cyan-50 relative z-10">Join hundreds of successful businesses that trust us with their digital transformation.</p>
            </div>
          </motion.aside>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass-card p-8 md:p-12 relative overflow-hidden rounded-3xl"
          >
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-500 to-purple-500"></div>
            <h3 className="text-4xl font-extrabold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">
              Let's Build the Future
            </h3>
            <p className="text-slate-400 mb-8 text-lg">
              Ready to transform your business? Get in touch and let's discuss how we can help you achieve your goals.
            </p>

            <form className="space-y-5" onSubmit={handleSubmit}>
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-300 ml-1">Your Name</label>
                <input
                  name="name"
                  required
                  className="w-full rounded-xl bg-slate-900/50 border border-slate-700 px-5 py-4 text-slate-100 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all placeholder:text-slate-600"
                  placeholder="John Doe"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-300 ml-1">Email Address</label>
                <input
                  name="email"
                  type="email"
                  required
                  className="w-full rounded-xl bg-slate-900/50 border border-slate-700 px-5 py-4 text-slate-100 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all placeholder:text-slate-600"
                  placeholder="john@example.com"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-300 ml-1">Your Message</label>
                <textarea
                  name="message"
                  required
                  rows={4}
                  className="w-full rounded-xl bg-slate-900/50 border border-slate-700 px-5 py-4 text-slate-100 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all placeholder:text-slate-600 resize-none"
                  placeholder="Tell us about your project..."
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-gradient-to-r from-cyan-500 to-purple-600 text-white font-bold py-4 rounded-xl shadow-lg shadow-cyan-500/20 hover:shadow-cyan-500/40 transition-all hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    Send Message
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </button>
            </form>
          </motion.div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-16 md:py-24 relative z-10">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-900/10 to-transparent pointer-events-none" />
        <div className="w-full px-0">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h3 className="text-3xl md:text-4xl font-bold mb-6">
              Trusted by <span className="text-cyan-400">Visionaries</span>
            </h3>
            <p className="text-slate-400 max-w-2xl mx-auto">
              See what our partners have to say about their journey with Grow Mantra.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((t, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="glass-card p-8 relative group hover:-translate-y-2 transition-transform duration-300"
              >
                <div className="absolute top-6 right-8 text-cyan-500/20 group-hover:text-cyan-500/40 transition-colors">
                  <svg width="40" height="40" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M14.017 21L14.017 18C14.017 16.0547 15.3738 15.122 15.632 15.122C14.9004 15.122 14.336 14.5576 14.336 13.826C14.336 13.0944 14.9004 12.53 15.632 12.53C16.3636 12.53 16.928 13.0944 16.928 13.826C16.928 14.027 16.881 14.215 16.799 14.383C16.551 15.539 15.485 16.67 14.017 16.954V21ZM5 21L5 18C5 16.0547 6.35683 15.122 6.61503 15.122C5.88342 15.122 5.31902 14.5576 5.31902 13.826C5.31902 13.0944 5.88342 12.53 6.61503 12.53C7.34663 12.53 7.91103 13.0944 7.91103 13.826C7.91103 14.027 7.86403 14.215 7.78203 14.383C7.53403 15.539 6.46803 16.67 5 16.954V21Z" />
                  </svg>
                </div>
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-14 h-14 rounded-xl bg-slate-900/50 border border-white/10 flex items-center justify-center shrink-0 group-hover:border-cyan-500/50 transition-colors">
                    {t.logo}
                  </div>
                  <div>
                    <div className="font-bold text-slate-100 text-lg">{t.name}</div>
                    <div className="text-xs text-cyan-400 font-medium uppercase tracking-wide">{t.role}</div>
                  </div>
                </div>
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                  ))}
                </div>
                <p className="text-slate-300 text-sm leading-relaxed italic">"{t.content}"</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 md:py-24 w-full px-0 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h3 className="text-3xl font-bold mb-4">Frequently Asked Questions</h3>
          <p className="text-slate-400">Everything you need to know about working with us.</p>
        </motion.div>

        <div className="glass-card p-8 rounded-3xl">
          {faqs.map((faq, i) => (
            <FAQItem key={i} question={faq.question} answer={faq.answer} />
          ))}
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-white/5 mt-20 py-12 relative z-10 bg-slate-950/50 backdrop-blur-sm">
        <div className="w-full px-0 flex flex-col md:flex-row items-center md:items-start justify-between gap-12">
          <div className="flex flex-col items-center md:items-start text-center md:text-left">
            <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">Grow Mantra</div>
            <p className="text-slate-400 mt-4 max-w-sm leading-relaxed">
              Transforming businesses with cutting-edge technology and innovative digital solutions.
            </p>
            <div className="mt-6 flex gap-4 justify-center md:justify-start">
              {['f', 't', 'in', 'ig'].map((social) => (
                <div key={social} className="w-10 h-10 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center hover:bg-cyan-500 hover:text-slate-900 transition-all cursor-pointer hover:-translate-y-1">
                  {social}
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 w-full md:w-auto text-center md:text-left">
            <div>
              <h5 className="font-bold text-slate-200 mb-4">Services</h5>
              <ul className="space-y-3 text-slate-400 text-sm">
                <li className="hover:text-cyan-400 cursor-pointer transition-colors">Web Development</li>
                <li className="hover:text-cyan-400 cursor-pointer transition-colors">AI Solutions</li>
                <li className="hover:text-cyan-400 cursor-pointer transition-colors">Digital Marketing</li>
                <li className="hover:text-cyan-400 cursor-pointer transition-colors">SEO Services</li>
              </ul>
            </div>

            <div>
              <h5 className="font-bold text-slate-200 mb-4">Company</h5>
              <ul className="space-y-3 text-slate-400 text-sm">
                <li className="hover:text-cyan-400 cursor-pointer transition-colors">About Us</li>
                <li className="hover:text-cyan-400 cursor-pointer transition-colors">Our Team</li>
                <li className="hover:text-cyan-400 cursor-pointer transition-colors">Careers</li>
                <li className="hover:text-cyan-400 cursor-pointer transition-colors">Contact</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="w-full px-0 mt-12 pt-8 border-t border-white/5 text-center text-slate-600 text-sm">
          © 2025 Grow Mantra. All rights reserved.
        </div>
      </footer>

      {/* Success Popup */}
      <AnimatePresence>
        {showSuccess && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 20 }}
              transition={{ type: "spring", duration: 0.5, bounce: 0.3 }}
              className="bg-slate-900 border border-cyan-500/30 p-8 rounded-3xl shadow-2xl max-w-md w-full relative text-center"
            >
              <button
                onClick={() => setShowSuccess(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-6 h-6" />
              </button>

              <div className="w-16 h-16 bg-cyan-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle2 className="w-8 h-8 text-cyan-400" />
              </div>

              <h3 className="text-2xl font-bold text-white mb-2">Details Submitted!</h3>
              <p className="text-slate-300">
                We'll get back to you within 24 hours.
              </p>

              <button
                onClick={() => setShowSuccess(false)}
                className="mt-8 w-full bg-cyan-500 text-slate-950 font-bold py-3 rounded-xl hover:bg-cyan-400 transition-colors"
              >
                Close
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </main>
  );
}
